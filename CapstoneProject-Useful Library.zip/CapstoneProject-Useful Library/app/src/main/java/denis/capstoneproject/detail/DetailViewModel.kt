package denis.capstoneproject.detail

import androidx.lifecycle.ViewModel
import com.denis.core.domain.model.MovieModel
import com.denis.core.domain.model.TvModel
import com.denis.core.domain.usecase.DataUseCase

class DetailViewModel(private val dataUseCase: DataUseCase) : ViewModel() {
    fun setFavoriteMovie(movie: MovieModel, newStatus:Boolean) = dataUseCase.setFavoriteMovie(movie, newStatus)
    fun setFavoriteTv(tv: TvModel, newStatus:Boolean) = dataUseCase.setFavoriteTv(tv, newStatus)
}

