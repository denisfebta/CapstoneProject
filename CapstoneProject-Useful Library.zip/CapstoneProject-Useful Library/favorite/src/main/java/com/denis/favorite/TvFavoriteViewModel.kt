package com.denis.favorite

import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import com.denis.core.domain.usecase.DataUseCase

class TvFavoriteViewModel(dataUseCase: DataUseCase) : ViewModel() {
    val favoriteTv = dataUseCase.getFavoriteTv().asLiveData()
}