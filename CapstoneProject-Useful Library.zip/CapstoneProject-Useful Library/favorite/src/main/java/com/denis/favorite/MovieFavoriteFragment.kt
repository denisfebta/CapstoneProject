package com.denis.favorite

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.denis.core.ui.MovieAdapter
import com.denis.favorite.databinding.FragmentMovieFavoriteBinding
import denis.capstoneproject.detail.DetailActivity
import org.koin.android.viewmodel.ext.android.viewModel

class MovieFavoriteFragment : Fragment() {

    private val movieFavoriteViewModel: MovieFavoriteViewModel by viewModel()

    private var _binding: FragmentMovieFavoriteBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        _binding = FragmentMovieFavoriteBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        if (activity != null) {

            val movieAdapter = MovieAdapter()
            movieAdapter.onItemClick = { selectedData ->
                val intent = Intent(activity, DetailActivity::class.java)
                intent.putExtra(DetailActivity.EXTRA_MOVIE, selectedData)
                startActivity(intent)
            }

            movieFavoriteViewModel.favoriteMovie.observe(viewLifecycleOwner, Observer { favorite ->
                if (favorite != null) {
                    movieAdapter.setData(favorite)
                    binding.viewEmpty.root.visibility = if (favorite.isNotEmpty()) View.INVISIBLE else View.VISIBLE
                }
            })

            with(binding.rvFavoriteMovie) {
                layoutManager = LinearLayoutManager(context)
                setHasFixedSize(true)
                adapter = movieAdapter
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
