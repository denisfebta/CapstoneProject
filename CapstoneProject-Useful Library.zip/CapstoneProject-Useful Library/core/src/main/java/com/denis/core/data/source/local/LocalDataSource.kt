package com.denis.core.data.source.local


import com.denis.core.data.source.local.entity.MovieEntity
import com.denis.core.data.source.local.entity.TvEntity
import com.denis.core.data.source.local.room.DataDao
import kotlinx.coroutines.flow.Flow

class LocalDataSource(private val dataDao: DataDao) {

    fun getAllMovie(): Flow<List<MovieEntity>> = dataDao.getAllMovie()

    fun getFavoriteMovie(): Flow<List<MovieEntity>> = dataDao.getFavoriteMovie()

    suspend fun insertMovie(list: List<MovieEntity>) = dataDao.insertMovie(list)

    fun setFavoriteMovie(dataList: MovieEntity, newState: Boolean) {
        dataList.favorite = newState
        dataDao.updateFavoriteMovie(dataList)
    }

    //

    fun getAllTv(): Flow<List<TvEntity>> = dataDao.getAllTv()

    fun getFavoriteTv(): Flow<List<TvEntity>> = dataDao.getFavoriteTv()

    suspend fun insertTv(list: List<TvEntity>) = dataDao.insertTv(list)

    fun setFavoriteTv(dataList: TvEntity, newState: Boolean) {
        dataList.favorite = newState
        dataDao.updateFavoriteTv(dataList)
    }
}