package com.denis.core.data.source.local.entity

import android.os.Parcelable
import androidx.annotation.NonNull
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.android.parcel.Parcelize

@Entity(tableName = "tv")
data class TvEntity (
    @PrimaryKey
    @NonNull
    @ColumnInfo(name = "id")
    val id: String,

    @ColumnInfo(name = "name")
    var title: String,

    @ColumnInfo(name = "first_air_date")
    var release: String,

    @ColumnInfo(name = "vote_average")
    var rating: String,

    @ColumnInfo(name = "overview")
    var description: String,

    @ColumnInfo(name = "poster_path")
    var poster: String,

    @ColumnInfo(name = "favorite")
    var favorite: Boolean = false
)