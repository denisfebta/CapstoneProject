package denis.capstoneproject.movie

import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import com.denis.core.domain.usecase.DataUseCase

class MovieViewModel(dataUseCase: DataUseCase) : ViewModel() {

    val dataMovie = dataUseCase.getAllMovie().asLiveData()

}