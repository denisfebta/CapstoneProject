package denis.capstoneproject.tv

import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import com.denis.core.domain.usecase.DataUseCase

class TvViewModel(dataUseCase: DataUseCase) : ViewModel() {

    val dataTv = dataUseCase.getAllTv().asLiveData()

}