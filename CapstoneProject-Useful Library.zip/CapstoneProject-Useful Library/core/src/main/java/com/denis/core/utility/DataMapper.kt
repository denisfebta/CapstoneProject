package com.denis.core.utility

import com.denis.core.data.source.local.entity.MovieEntity
import com.denis.core.data.source.local.entity.TvEntity
import com.denis.core.data.source.remote.response.MovieResponse
import com.denis.core.data.source.remote.response.TvResponse
import com.denis.core.domain.model.MovieModel
import com.denis.core.domain.model.TvModel

object DataMapper {
    fun mapResponsesToMovieEntities(input: List<MovieResponse>): List<MovieEntity> {
        val dataList = ArrayList<MovieEntity>()
        input.map {
            val data = MovieEntity(
                id = it.id,
                description = it.description,
                title = it.title,
                rating = it.rating,
                release = it.release,
                poster = it.poster,
                favorite = false
            )
            dataList.add(data)
        }
        return dataList
    }

    fun mapResponsesToTvEntities(input: List<TvResponse>): List<TvEntity> {
        val dataList = ArrayList<TvEntity>()
        input.map {
            val data = TvEntity(
                id = it.id,
                description = it.description,
                title = it.title,
                rating = it.rating,
                release = it.release,
                poster = it.poster,
                favorite = false
            )
            dataList.add(data)
        }
        return dataList
    }

    // NewMapper Movie

    fun mapEntitiesToDomainMovie(input: List<MovieEntity>): List<MovieModel> =
        input.map {
            MovieModel(
                id = it.id,
                description = it.description,
                title = it.title,
                rating = it.rating,
                release = it.release,
                poster = it.poster,
                favorite = it.favorite
            )
        }

    fun mapDomainToEntityMovie(input: MovieModel) = MovieEntity (
        id = input.id,
        description = input.description,
        title = input.title,
        rating = input.rating,
        release = input.release,
        poster = input.poster,
        favorite = input.favorite
    )

    // NewMapper TV

    fun mapEntitiesToDomainTv(input: List<TvEntity>): List<TvModel> =
        input.map {
            TvModel(
                id = it.id,
                description = it.description,
                title = it.title,
                rating = it.rating,
                release = it.release,
                poster = it.poster,
                favorite = it.favorite
            )
        }

    fun mapDomainToEntityTv(input: TvModel) = TvEntity (
        id = input.id,
        description = input.description,
        title = input.title,
        rating = input.rating,
        release = input.release,
        poster = input.poster,
        favorite = input.favorite
    )
}