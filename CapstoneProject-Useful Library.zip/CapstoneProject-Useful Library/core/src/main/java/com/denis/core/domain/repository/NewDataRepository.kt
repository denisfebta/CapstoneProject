package com.denis.core.domain.repository

import com.denis.core.data.Resource
import com.denis.core.domain.model.MovieModel
import com.denis.core.domain.model.TvModel
import kotlinx.coroutines.flow.Flow

interface NewDataRepository {

    fun getAllMovie(): Flow<Resource<List<MovieModel>>>

    fun getFavoriteMovie(): Flow<List<MovieModel>>

    fun setFavoriteMovie(movie: MovieModel, state: Boolean)

    fun getAllTv(): Flow<Resource<List<TvModel>>>

    fun getFavoriteTv(): Flow<List<TvModel>>

    fun setFavoriteTv(tv: TvModel, state: Boolean)

}