package denis.capstoneproject.di

import com.denis.core.domain.usecase.DataInteractor
import com.denis.core.domain.usecase.DataUseCase
import denis.capstoneproject.detail.DetailViewModel
import denis.capstoneproject.movie.MovieViewModel
import denis.capstoneproject.tv.TvViewModel
import org.koin.android.viewmodel.dsl.viewModel
import org.koin.dsl.module

val useCaseModule = module {
    factory<DataUseCase> { DataInteractor(get()) }
}

val viewModelModule = module {
    viewModel { MovieViewModel(get()) }
    viewModel { TvViewModel(get()) }
    viewModel { DetailViewModel(get()) }
}