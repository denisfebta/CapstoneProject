package com.denis.core.data.source.local.room

import androidx.room.*
import com.denis.core.data.source.local.entity.MovieEntity
import com.denis.core.data.source.local.entity.TvEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface DataDao {

    @Query("SELECT * FROM movie")
    fun getAllMovie(): Flow<List<MovieEntity>>

    @Query("SELECT * FROM movie where favorite = 1")
    fun getFavoriteMovie(): Flow<List<MovieEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMovie(data: List<MovieEntity>)

    @Update
    fun updateFavoriteMovie(data: MovieEntity)

    //

    @Query("SELECT * FROM tv")
    fun getAllTv(): Flow<List<TvEntity>>

    @Query("SELECT * FROM tv where favorite = 1")
    fun getFavoriteTv(): Flow<List<TvEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTv(data: List<TvEntity>)

    @Update
    fun updateFavoriteTv(data: TvEntity)
}
