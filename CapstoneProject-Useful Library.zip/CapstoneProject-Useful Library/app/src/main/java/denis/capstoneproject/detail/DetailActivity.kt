package denis.capstoneproject.detail

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.denis.core.domain.model.MovieModel
import com.denis.core.domain.model.TvModel
import com.denis.core.utility.Constants
import denis.capstoneproject.R
import denis.capstoneproject.databinding.ActivityDetailBinding
import org.koin.android.viewmodel.ext.android.viewModel

class DetailActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_MOVIE = "extra_movie"
        const val EXTRA_TV = "extra_tv"
    }

    private val detailViewModel: DetailViewModel by viewModel()
    private lateinit var binding: ActivityDetailBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val detailMovie = intent.getParcelableExtra<MovieModel>(EXTRA_MOVIE)
        showDetailMovie(detailMovie)

        val detailTv = intent.getParcelableExtra<TvModel>(EXTRA_TV)
        showDetailTv(detailTv)
    }

    private fun showDetailMovie(detailMovie: MovieModel?) {
        detailMovie?.let {
            supportActionBar?.title = detailMovie.title
            binding.content.tvDetailDescription.text = detailMovie.description

            Glide.with(this@DetailActivity)
                .load((Constants.IMG_URL)+detailMovie.poster)
                .into(binding.ivDetailImage)

            var statusFavorite = detailMovie.favorite
            setStatusFavorite(statusFavorite)
            binding.fab.setOnClickListener {
                statusFavorite = !statusFavorite
                detailViewModel.setFavoriteMovie(detailMovie, statusFavorite)
                setStatusFavorite(statusFavorite)
            }
        }
    }

    private fun showDetailTv(detailTv: TvModel?) {
        detailTv?.let {
            supportActionBar?.title = detailTv.title
            binding.content.tvDetailDescription.text = detailTv.description

            Glide.with(this@DetailActivity)
                .load((Constants.IMG_URL)+detailTv.poster)
                .into(binding.ivDetailImage)

            var statusFavorite = detailTv.favorite
            setStatusFavorite(statusFavorite)
            binding.fab.setOnClickListener {
                statusFavorite = !statusFavorite
                detailViewModel.setFavoriteTv(detailTv, statusFavorite)
                setStatusFavorite(statusFavorite)
            }
        }
    }

    private fun setStatusFavorite(statusFavorite: Boolean) {
        if (statusFavorite) {
            binding.fab.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_favorite_white))
        } else {
            binding.fab.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_not_favorite_white))
        }
    }
}
