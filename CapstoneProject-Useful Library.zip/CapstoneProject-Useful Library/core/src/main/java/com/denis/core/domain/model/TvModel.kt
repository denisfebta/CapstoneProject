package com.denis.core.domain.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class TvModel (
    val id: String,
    var title: String,
    var release: String,
    var rating: String,
    var description: String,
    var poster: String,
    var favorite: Boolean
): Parcelable