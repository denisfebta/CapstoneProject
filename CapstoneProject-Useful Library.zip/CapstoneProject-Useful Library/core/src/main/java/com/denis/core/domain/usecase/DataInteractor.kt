package com.denis.core.domain.usecase

import com.denis.core.domain.model.MovieModel
import com.denis.core.domain.model.TvModel
import com.denis.core.domain.repository.NewDataRepository


class DataInteractor(private val dataRepository: NewDataRepository): DataUseCase {

    override fun getAllMovie() = dataRepository.getAllMovie()

    override fun getFavoriteMovie() = dataRepository.getFavoriteMovie()

    override fun setFavoriteMovie(movie: MovieModel, state: Boolean) = dataRepository.setFavoriteMovie(movie, state)

    override fun getAllTv() = dataRepository.getAllTv()

    override fun getFavoriteTv() = dataRepository.getFavoriteTv()

    override fun setFavoriteTv(tv: TvModel, state: Boolean) = dataRepository.setFavoriteTv(tv, state)

}