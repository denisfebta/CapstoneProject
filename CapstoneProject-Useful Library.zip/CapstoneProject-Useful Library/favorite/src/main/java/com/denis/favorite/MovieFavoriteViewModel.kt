package com.denis.favorite

import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import com.denis.core.domain.usecase.DataUseCase

class MovieFavoriteViewModel(dataUseCase: DataUseCase) : ViewModel() {
    val favoriteMovie = dataUseCase.getFavoriteMovie().asLiveData()
}