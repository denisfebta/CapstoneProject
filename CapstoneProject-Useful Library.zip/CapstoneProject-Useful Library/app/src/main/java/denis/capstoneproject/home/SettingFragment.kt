package denis.capstoneproject.home

import android.os.Bundle
import android.widget.Toast
import androidx.preference.Preference
import androidx.preference.PreferenceFragmentCompat
import androidx.preference.SwitchPreferenceCompat
import denis.capstoneproject.R


class SettingFragment : PreferenceFragmentCompat() {

    private val alarmReceiver = AlarmReceiver()

    override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
        setPreferencesFromResource(R.xml.preference, rootKey)

        val dailyReminderSwitch = findPreference<SwitchPreferenceCompat>("notifications")

        dailyReminderSwitch?.onPreferenceChangeListener = Preference.OnPreferenceChangeListener{ _, _ ->
            if (dailyReminderSwitch?.isChecked!!) {
                activity?.let { alarmReceiver.cancelAlarm(it) }
                val text = R.string.notification_disable
                Toast.makeText(activity, text, Toast.LENGTH_SHORT).show()
                dailyReminderSwitch.isChecked = false
            } else {
                activity?.let { alarmReceiver.setRepeatAlarm(it) }
                val text = R.string.notification_enable
                Toast.makeText(activity, text, Toast.LENGTH_SHORT).show()
                dailyReminderSwitch.isChecked = true
            }
            false
        }
    }
}
