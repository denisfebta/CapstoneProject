package com.denis.favorite

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.denis.favorite.databinding.ActivityFavoriteBinding
import org.koin.core.context.loadKoinModules

class FavoriteActivity : AppCompatActivity() {

    private lateinit var binding: ActivityFavoriteBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFavoriteBinding.inflate(layoutInflater)
        setContentView(binding.root)

        loadKoinModules(favoriteModule)

        val sectionPagerAdapter = ViewPager(this, supportFragmentManager)
        binding.favoriteViewPager.adapter = sectionPagerAdapter
        binding.tabLayout.setupWithViewPager(binding.favoriteViewPager)
    }
}