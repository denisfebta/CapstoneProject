package com.denis.core.data.source.remote.response

import com.google.gson.annotations.SerializedName

data class TvResponse (

    @field:SerializedName("id")
    val id: String,

    @field:SerializedName("name")
    val title: String,

    @field:SerializedName("first_air_date")
    val release: String,

    @field:SerializedName("vote_average")
    val rating: String,

    @field:SerializedName("overview")
    val description: String,

    @field:SerializedName("poster_path")
    val poster: String,
)