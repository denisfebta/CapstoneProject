package com.denis.core.data

import com.denis.core.data.source.local.LocalDataSource
import com.denis.core.data.source.remote.RemoteDataSource
import com.denis.core.data.source.remote.network.ApiResponse
import com.denis.core.data.source.remote.response.MovieResponse
import com.denis.core.data.source.remote.response.TvResponse
import com.denis.core.domain.model.MovieModel
import com.denis.core.domain.model.TvModel
import com.denis.core.domain.repository.NewDataRepository
import com.denis.core.utility.AppExecutors
import com.denis.core.utility.DataMapper
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map


class DataRepository(private val remoteDataSource: RemoteDataSource, private val localDataSource: LocalDataSource, private val appExecutors: AppExecutors) :
    NewDataRepository {

    override fun getAllMovie(): Flow<Resource<List<MovieModel>>> =
        object : NetworkBoundResource<List<MovieModel>, List<MovieResponse>>() {
            override fun loadFromDB(): Flow<List<MovieModel>> {
                return localDataSource.getAllMovie().map { DataMapper.mapEntitiesToDomainMovie(it) }
            }

            override fun shouldFetch(data: List<MovieModel>?): Boolean =
                data == null || data.isEmpty()

            override suspend fun createCall(): Flow<ApiResponse<List<MovieResponse>>> =
                remoteDataSource.getAllMovie()

            override suspend fun saveCallResult(data: List<MovieResponse>) {
                val dataList = DataMapper.mapResponsesToMovieEntities(data)
                localDataSource.insertMovie(dataList)
            }
        }.asFlow()

    override fun getFavoriteMovie(): Flow<List<MovieModel>> {
        return localDataSource.getFavoriteMovie().map { DataMapper.mapEntitiesToDomainMovie(it) }
    }

    override fun setFavoriteMovie(movie: MovieModel, state: Boolean) {
        val movieEntity = DataMapper.mapDomainToEntityMovie(movie)
        appExecutors.diskIO().execute { localDataSource.setFavoriteMovie(movieEntity, state) }
    }

    //

    override fun getAllTv(): Flow<Resource<List<TvModel>>> =
        object : NetworkBoundResource<List<TvModel>, List<TvResponse>>() {
            override fun loadFromDB(): Flow<List<TvModel>> {
                return localDataSource.getAllTv().map { DataMapper.mapEntitiesToDomainTv(it)
                }
            }

            override fun shouldFetch(data: List<TvModel>?): Boolean =
                data == null || data.isEmpty()

            override suspend fun createCall(): Flow<ApiResponse<List<TvResponse>>> =
                remoteDataSource.getAllTv()

            override suspend fun saveCallResult(data: List<TvResponse>) {
                val dataList = DataMapper.mapResponsesToTvEntities(data)
                localDataSource.insertTv(dataList)
            }
        }.asFlow()

    override fun getFavoriteTv(): Flow<List<TvModel>> {
        return localDataSource.getFavoriteTv().map { DataMapper.mapEntitiesToDomainTv(it) }
    }

    override fun setFavoriteTv(tv: TvModel, state: Boolean) {
        val tvEntity = DataMapper.mapDomainToEntityTv(tv)
        appExecutors.diskIO().execute { localDataSource.setFavoriteTv(tvEntity, state) }
    }
}

