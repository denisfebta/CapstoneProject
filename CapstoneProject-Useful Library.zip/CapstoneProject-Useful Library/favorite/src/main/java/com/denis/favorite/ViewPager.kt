package com.denis.favorite

import android.content.Context
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import denis.capstoneproject.R

class ViewPager (private val context: Context, fm: FragmentManager): FragmentPagerAdapter(fm, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT) {
    companion object{private val TAB_TITLE = intArrayOf(R.string.menu_home, R.string.menu_tv)}
    override fun getCount(): Int = TAB_TITLE.size

    override fun getItem(position: Int): Fragment = when(position){
        0 -> MovieFavoriteFragment()
        1 -> TvFavoriteFragment()
        else -> Fragment()
    }

    override fun getPageTitle(position: Int): CharSequence? = context.getString(TAB_TITLE[position])
}