package com.denis.core.data.source.remote.network

import com.denis.core.data.source.remote.response.MovieListResponse
import com.denis.core.data.source.remote.response.TvListResponse
import com.denis.core.utility.Constants.API_KEY
import retrofit2.http.GET

interface ApiService {

    @GET("movie/popular?api_key=$API_KEY")
    suspend fun apiMovie(): MovieListResponse

    @GET("tv/popular?api_key=$API_KEY")
    suspend fun apiTv(): TvListResponse

}